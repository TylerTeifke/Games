package mastermind;

public class Guess2 {
	
	private String sourceGuess;
	private int size;
	private int[] position;
	
	public Guess2(String guess){
		this.sourceGuess = guess;
	}
	
	public String getSourceGuess() {
		return sourceGuess;
	}
	
	public int getPosition(int index) {
		return position[index];
	}
	
	public boolean validateGuess() {
		String slot0;
		String slot1;
		String slot2;
		String slot3;
		
		if(sourceGuess.length() != 4) {
			return false;
		}
		
		slot0 = sourceGuess.substring(0, 1);
		slot1 = sourceGuess.substring(1, 2);
		slot2 = sourceGuess.substring(2, 3);
		slot3 = sourceGuess.substring(3, 4);
		
		int i1;										//If the slots are letters, than the program will still know what to do
		try {
			i1 = Integer.parseInt(slot0);
		}
		catch(NumberFormatException a)
		{
			i1 = 0;
		}
		
		int i2;										
		try {
			i2 = Integer.parseInt(slot1);
		}
		catch(NumberFormatException a)
		{
			i2 = 0;
		}
		
		int i3;										
		try {
			i3 = Integer.parseInt(slot2);
		}
		catch(NumberFormatException a)
		{
			i3 = 0;
		}
		
		int i4;										
		try {
			i4 = Integer.parseInt(slot3);
		}
		catch(NumberFormatException a)
		{
			i4 = 0;
		}
		
		if(i1 > 8 || i1 < 1) {
			return false;
		}
		
		if(i2 > 8 || i2 < 1) {
			return false;
		}
		
		if(i3 > 8 || i3 < 1) {
			return false;
		}
		
		if(i4 > 8 || i4 < 1) {
			return false;
		}
		
		if(i1 == i2 ||
		   i1 == i3 ||
		   i1 == i4) {
			return false;
		}
		
		if(i2 == i3 ||
		   i2 == i4) {
			return false;
		}
		
		if(i3 == i4) {
			return false;
		}
		
		position = new int[4];
		position[0] = i1;
		position[1] = i2;
		position[2] = i3;
		position[3] = i4;
		
		return true;
	}

}
