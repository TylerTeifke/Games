package mastermind;

import java.util.Random;

public class Solution2 {
	
	private int position[];
	private int size;
	
	public Solution2(int i1, int i2, int i3, int i4) {
		position = new int[4];				//creates new array spaces
		position[0] = i1;
		position[1] = i2;
		position[2] = i3;
		position[3] = i4;
		size = 4;
	}
	
	public Solution2() {
		position = new int[4];
		Random rand = new Random();
		position[0] = rand.nextInt(8) + 1;
		
		position[1] = position[0];
		while(position[0] == position[1]) {
			position[1] = rand.nextInt(8) + 1;
		}
		
		position[2] = position[0];
		while(position[0] == position[2] || position[1] == position[2]) {
			position[2] = rand.nextInt(8) + 1;
		}
		
		position[3] = position[0];
		while(position[0] == position[3] || position[1] == position[3] || position[2] == position[3]) {
			position[3] = rand.nextInt(8) + 1;
		}
		//All positions are now different
		
		size = 4;
	}
	
	public int getPosition(int index) {
		return position[index];
	}
	
	public String toString() {
		//return position[0] + "" + position[1] + "" + position[2] + "" + position[3];
		String retString = "";
		
		for(int i = 0; i < size; i++) {
			retString = retString + position[i];
		}
		return retString;
	}
	
	public String getHint(Guess2 guess) {
		String hint = "";
		int numOfStar = 0;
		int anyMatch = 0;
		int numOfDash = 0;
		
		//Comparing guess to solution
		for(int i = 0; i < size; i++) {
			if(position[i] == guess.getPosition(i)) {
				numOfStar++;
			}
		}
		
		for(int i = 0; i < size; i++) {
			for(int j = 0; j < size; j++) {
				if(position[i] == guess.getPosition(j)) {
					anyMatch++;
				}
			}
		}
		
		numOfDash = anyMatch - numOfStar;
		
		for(int i = 1; i <= numOfStar; i++) {
			hint = hint + "*";
		}
		
		for(int i = 1; i <= numOfDash; i++) {
			hint = hint + "-";
		}
		
		return hint;
	}
}