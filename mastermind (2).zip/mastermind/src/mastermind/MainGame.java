package mastermind;

import java.util.Scanner;

public class MainGame {

	public static void main(String[] args) {
		System.out.println("Starting Mastermind game.");
		
		playGame();
		//testHint();
		//testSolution2();
		
		System.out.println("Ending Mastermind game.");

	}
	
	public static void test1() {
		System.out.println("Begin test 1");
		
		Guess g1 = new Guess("");
		Guess g2 = new Guess("1234567");
		Guess g3 = new Guess("123456");
		Guess g4 = new Guess("12345678");
		Guess g5 = new Guess("1 2 3 4");
		Guess g6 = new Guess("12 3 4 5");
		Guess g7 = new Guess("1 3 5 7");
		Guess g8 = new Guess("9 3 4 5");
		Guess g9 = new Guess("B 3 4 6");
		Guess g10 = new Guess("1 d 4 6");
		Guess g11 = new Guess("4 3 t 6");
		Guess g12 = new Guess("7 3 4 g");
		Guess g13 = new Guess("B 3 j 6");
		
		System.out.println(g1.getSourceGuess() + " valid = " + g1.validateGuess());
		System.out.println(g2.getSourceGuess() + " valid = " + g2.validateGuess());
		System.out.println(g3.getSourceGuess() + " valid = " + g3.validateGuess());
		System.out.println(g4.getSourceGuess() + " valid = " + g4.validateGuess());
		System.out.println(g5.getSourceGuess() + " valid = " + g5.validateGuess());
		System.out.println(g6.getSourceGuess() + " valid = " + g6.validateGuess());
		System.out.println(g7.getSourceGuess() + " valid = " + g7.validateGuess());
		System.out.println(g8.getSourceGuess() + " valid = " + g8.validateGuess());
		System.out.println(g9.getSourceGuess() + " valid = " + g9.validateGuess());
		System.out.println(g10.getSourceGuess() + " valid = " + g10.validateGuess());
		System.out.println(g11.getSourceGuess() + " valid = " + g11.validateGuess());
		System.out.println(g12.getSourceGuess() + " valid = " + g12.validateGuess());
		System.out.println(g13.getSourceGuess() + " valid = " + g13.validateGuess());
		
		System.out.println("End test 1");
	}
	
	public static void test2() {
		System.out.println("Begin test 2.");
		String str;
		Scanner s = new Scanner(System.in);
		
		//get guess from user
		System.out.println("Input guess: ");
		str = s.nextLine();
		Guess g1 = new Guess(str);
		System.out.println(g1.getSourceGuess() + " valid = " + g1.validateGuess());
		
		System.out.println("End test 2.");
	}
	
	public static void test3() {
		System.out.println("Begin test 3.");
		Solution s1 = new Solution(1,2,3,4);
		Solution s2 = new Solution(5,6,7,3);
		Solution s3 = new Solution(1,1,1,1);
		Solution s4 = new Solution(5,3,1,7);
		Solution s5 = new Solution();
		System.out.println("s1 = " + s1.toString());
		System.out.println("s2 = " + s2.toString());
		System.out.println("s3 = " + s3.toString());
		System.out.println("s4 = " + s4.toString());
		System.out.println("s5 = " + s5.toString());
	}
	
	public static void test4() {
		System.out.println("Begin test 4.");
		
		for(int i = 1; i < 21; i++) {
			Solution s = new Solution();
			System.out.println("s = " + s.toString());
		}
		System.out.println("End test 4.");
	}
	
	public static void playGame() {
		System.out.println("Start Playing Game");
		Solution2 s = new Solution2(1,2,3,4);
		boolean finished = false;
		
		while(!finished) {
			System.out.print("Enter Guess:");
			String str;
			Scanner sc = new Scanner(System.in);
			str = sc.nextLine();
			if(str.equalsIgnoreCase("quit")) {
				finished = true;
			}
			
			else {
				Guess2 g1 = new Guess2(str);
				if(g1.validateGuess() == true) {
					String hint = s.getHint(g1);
					System.out.println("            " + str + "  :  " + hint);
					
					if(hint.equalsIgnoreCase("****")) {
						System.out.println("Congratulations, you won.");
						finished = true;
					}
				}
				
				else {
					System.out.println("Invalid Guess Format, Try Again.");
				}
			}
		}
		System.out.println("Finished Playing Game");
	}
	
	public static void testHint() {
		Solution sol = new Solution(1,2,3,4);
		
		Guess g1 = new Guess("1267");
		g1.validateGuess();
		String hint = sol.getHint(g1);
		if(hint.equalsIgnoreCase("**")) {
			System.out.println("Solution " + sol.toString() + " guess " + g1.getSourceGuess() + " hint " + hint + " PASS");
		}
		else {
			System.out.println("Solution " + sol.toString() + " guess " + g1.getSourceGuess() + " hint " + hint + " FAILED");
		}
		
		Guess g2 = new Guess("1456");
		g2.validateGuess();
		String hint2 = sol.getHint(g2);
		if(hint2.equalsIgnoreCase("*-")) {
			System.out.println("Solution " + sol.toString() + " guess " + g2.getSourceGuess() + " hint " + hint2 + " PASS");
		}
		else {
			System.out.println("Solution " + sol.toString() + " guess " + g2.getSourceGuess() + " hint " + hint2 + " FAILED");
		}
		
		Guess g3 = new Guess("4321");
		g3.validateGuess();
		String hint3 = sol.getHint(g3);
		if(hint3.equalsIgnoreCase("----")) {
			System.out.println("Solution " + sol.toString() + " guess " + g3.getSourceGuess() + " hint " + hint3 + " PASS");
		}
		else {
			System.out.println("Solution " + sol.toString() + " guess " + g3.getSourceGuess() + " hint " + hint3 + " FAILED");
		}
		
		Guess g4 = new Guess("1243");
		g4.validateGuess();
		String hint4 = sol.getHint(g4);
		if(hint4.equalsIgnoreCase("**--")) {
			System.out.println("Solution " + sol.toString() + " guess " + g4.getSourceGuess() + " hint " + hint4 + " PASS");
		}
		else {
			System.out.println("Solution " + sol.toString() + " guess " + g4.getSourceGuess() + " hint " + hint4 + " FAILED");
		}
		
		Guess g5 = new Guess("5678");
		g5.validateGuess();
		String hint5 = sol.getHint(g5);
		if(hint5.equalsIgnoreCase("")) {
			System.out.println("Solution " + sol.toString() + " guess " + g5.getSourceGuess() + " hint " + hint5 + " PASS");
		}
		else {
			System.out.println("Solution " + sol.toString() + " guess " + g5.getSourceGuess() + " hint " + hint5 + " FAILED");
		}
		
		Guess g6 = new Guess("1234");
		g6.validateGuess();
		String hint6 = sol.getHint(g6);
		if(hint6.equalsIgnoreCase("****")) {
			System.out.println("Solution " + sol.toString() + " guess " + g6.getSourceGuess() + " hint " + hint6 + " PASS");
		}
		else {
			System.out.println("Solution " + sol.toString() + " guess " + g6.getSourceGuess() + " hint " + hint6 + " FAILED");
		}
	}
	
	public static void testSolution2() {
		Solution2 a = new Solution2(1,2,3,4);
		System.out.println("a = " + a.toString());
		
		Solution2 b = new Solution2();
		System.out.println("b = " + b.toString());
		Guess2 g = new Guess2("2345");
		System.out.println("    " + g.getSourceGuess());
		g.validateGuess();
		System.out.println(b.getHint(g));
	}
	
	
}