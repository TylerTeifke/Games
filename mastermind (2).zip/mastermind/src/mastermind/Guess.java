package mastermind;

public class Guess {

	private String sourceGuess;
	
	private int position1;
	private int position2;
	private int position3;
	private int position4;
	
	public Guess(String guess){
		sourceGuess = guess;
	}
	public String getSourceGuess() {
		return sourceGuess;
	}
	public void setSourceGuess(String sourceGuess) {
		this.sourceGuess = sourceGuess;
	}
	
	public boolean validateGuess() {
		String slot0;
		String slot1;
		String slot2;
		String slot3;
		
		if(sourceGuess.length() != 4) {
			return false;
		}
		
		slot0 = sourceGuess.substring(0, 1);
		slot1 = sourceGuess.substring(1, 2);
		slot2 = sourceGuess.substring(2, 3);
		slot3 = sourceGuess.substring(3, 4);
		//int i1 = Integer.parseInt(slot0);
		//int i2 = Integer.parseInt(slot2);
		//int i3 = Integer.parseInt(slot4);
		//int i4 = Integer.parseInt(slot6);
		
		int i1;										//If the slots are letters, than the program will still know what to do
		try {
			i1 = Integer.parseInt(slot0);
		}
		catch(NumberFormatException a)
		{
			i1 = 0;
		}
		
		int i2;										
		try {
			i2 = Integer.parseInt(slot1);
		}
		catch(NumberFormatException a)
		{
			i2 = 0;
		}
		
		int i3;										
		try {
			i3 = Integer.parseInt(slot2);
		}
		catch(NumberFormatException a)
		{
			i3 = 0;
		}
		
		int i4;										
		try {
			i4 = Integer.parseInt(slot3);
		}
		catch(NumberFormatException a)
		{
			i4 = 0;
		}
		
		if(i1 > 8 || i1 < 1) {
			return false;
		}
		
		if(i2 > 8 || i2 < 1) {
			return false;
		}
		
		if(i3 > 8 || i3 < 1) {
			return false;
		}
		
		if(i4 > 8 || i4 < 1) {
			return false;
		}
		
		if(i1 == i2 ||
		   i1 == i3 ||
		   i1 == i4) {
			return false;
		}
		
		if(i2 == i3 ||
		   i2 == i4) {
			return false;
		}
		
		if(i3 == i4) {
			return false;
		}
		
		position1 = i1;
		position2 = i2;
		position3 = i3;
		position4 = i4;
		
		return true;
	}
	public int getPosition1() {
		return position1;
	}
	public void setPosition1(int position1) {
		this.position1 = position1;
	}
	public int getPosition2() {
		return position2;
	}
	public void setPosition2(int position2) {
		this.position2 = position2;
	}
	public int getPosition3() {
		return position3;
	}
	public void setPosition3(int position3) {
		this.position3 = position3;
	}
	public int getPosition4() {
		return position4;
	}
	public void setPosition4(int position4) {
		this.position4 = position4;
	}
}
