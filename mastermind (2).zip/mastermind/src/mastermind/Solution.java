package mastermind;

import java.util.Random;

public class Solution {

	private int position1;
	private int position2;
	private int position3;
	private int position4;
	
	public Solution(int i1, int i2, int i3, int i4) {
		position1 = i1;
		position2 = i2;
		position3 = i3;
		position4 = i4;
	}
	
	public Solution() {
		Random rand = new Random();
		position1 = rand.nextInt(8) + 1;
		
		position2 = position1;
		while(position1 == position2) {
			position2 = rand.nextInt(8) + 1;
		}
		//position1 and position2 are now different
		
		position3 = position1;
		while(position1 == position3 || position2 == position3) {
			position3 = rand.nextInt(8) + 1;
		}
		//position1, position2, and position3 are now different
		
		position4 = position1;
		while(position1 == position4 || position2 == position4 || position3 == position4) {
			position4 = rand.nextInt(8) + 1;
		}
		//position1, position2, position3, and position4 are now different
	}
	
	public int getPosition1() {
		return position1;
	}
	public void setPosition1(int position1) {
		this.position1 = position1;
	}
	
	public int getPosition2() {
		return position2;
	}
	public void setPosition2(int position2) {
		this.position2 = position2;
	}
	
	public int getPosition3() {
		return position3;
	}
	public void setPosition3(int position3) {
		this.position3 = position3;
	}
	
	public int getPosition4() {
		return position4;
	}
	public void setPosition4(int position4) {
		this.position4 = position4;
	}
	
	public String toString() {
		return position1 + "" + position2 + "" + position3 + "" + position4;
	}
	
	public String getHint(Guess guess) {
		String hint = "";
		int numOfStar = 0;
		int anyMatch = 0;
		int numOfDash = 0;
		
		if(position1 == guess.getPosition1()) {
			numOfStar++;
		}
		
		if(position2 == guess.getPosition2()) {
			numOfStar++;
		}
		
		if(position3 == guess.getPosition3()) {
			numOfStar++;
		}
		
		if(position4 == guess.getPosition4()) {
			numOfStar++;
		}
		
		if(position1 == guess.getPosition1() || 
		   position2 == guess.getPosition1() || 
		   position3 == guess.getPosition1() || 
		   position4 == guess.getPosition1()) {
			anyMatch++;
		}
		
		if(position1 == guess.getPosition2() || 
		   position2 == guess.getPosition2() || 
		   position3 == guess.getPosition2() || 
		   position4 == guess.getPosition2()) {
			anyMatch++;
		}
		
		if(position1 == guess.getPosition3() || 
		   position2 == guess.getPosition3() || 
		   position3 == guess.getPosition3() || 
		   position4 == guess.getPosition3()) {
			anyMatch++;
		}
		
		if(position1 == guess.getPosition4() || 
		   position2 == guess.getPosition4() || 
		   position3 == guess.getPosition4() || 
		   position4 == guess.getPosition4()) {
			anyMatch++;
		}
		
		numOfDash = anyMatch - numOfStar;
		
		for(int i = 1; i <= numOfStar; i++) {
			hint = hint + "*";
		}
		
		for(int i = 1; i <= numOfDash; i++) {
			hint = hint + "-";
		}
		
		return hint;
	}
}
