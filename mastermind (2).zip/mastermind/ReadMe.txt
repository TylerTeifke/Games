In this game there are four colored circles. You click on them to cycle through the available colors,
and then click on the arrow to input a sequence of colors as your guess. The game will then give you a hint
to the solution in the form of a set of four colored circles. White means wrong color, gray means right color 
in the wrong spot, and black means right color in the right spot. The game ends when you guess all of the right colors
in the right spots.